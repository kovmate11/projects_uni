// ./hazi2 -s d=/dev/ttyACM0,s=115200

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#include <fcntl.h>
#include <termios.h>
#include <unistd.h>

//Globális változók
#define BUFLEN (32)    //buffer hossza
char game[] = "A játék elején megadja a játkos nevét, majd a nehézségi szintet. Teljes név után entert kell ütni és a nehézségi szint után is entert kell ütni. A nehézségi szint kiválasztása után egyből elindul a játék. A j és b gombok segítségével tudsz lépegetni, minden gombnyomás után entert kell nyomni úgy érzékelia bejövő adatot.";
char player_name[BUFLEN];                                               //játékos nevének a tárolására szolgál
char level = 0;                                                         //bekért nehézségi szint eltárolása
char tmp_level[2];                                                      //a nehézségi szint tovább küldése a mikrokontrollernek
char result[BUFLEN];                                                    //az eredmény eltárolása amit a mikrokontroller visszaküld
char difficulty_level[BUFLEN];                                          //fájlba mentésre és a kiíratásra szolgáló nehézségi szintnek a tömbje
char gecko_in = 0;														//a beolvasott kartaknernek a változója
char gecko_out[2];														//a kiküldendő adathalmaz tömbje
char start[] = {'s', '\0'} ;                                            //kezdő karakter kiküldése a mikrokontroller számára
bool EXIT_player = false;                                               //a játékos név állapot változója
bool EXIT_level = false;                                                //a nehézségi szint állapot változója
bool EXIT_game = false;                                                 //a játék állapot változója



#define CMDLINE_DBG true
#define CFGSTR_SIZE 64
#define FILENAME_SIZE 1024
#define TTYLINE_S	IZE 256
uint32_t g_serial_speed = 0;
uint32_t g_termio_speed = 0;
char g_serial_device[CFGSTR_SIZE] = "";
char g_infile[FILENAME_SIZE] = "stdin"; 
char g_outfile[FILENAME_SIZE] = "stdout"; 

// Accessing termios.h Bnum type speed definition from the command line
struct BNUM_speed {
	uint32_t speed;
	uint32_t bnum;
};

// Konstansok /usr/include/asm-generic/termbits.h -ból
// A konstansok oktálisak termbits.h -ban
struct BNUM_speed g_speed[] = {
	{ 50 , B50 },
    { 75 , B75 },
	{ 110 , B110 },
	{ 134 , B134 },
	{ 150 , B150 },
	{ 200 , B200 },
	{ 300 , B300 },
	{ 600 , B600 },
	{ 1200 , B1200 },
	{ 1800 , B1800 },
	{ 2400 , B2400 },
	{ 4800 , B4800 },
	{ 9600 , B9600 },
	{ 19200 , B19200 },
	{ 38400 , B38400 },
	{ 57600 , B57600 },
	{ 115200, B115200 },
	{ 230400 , B230400 },
	{ 460800 , B460800 },
	{ 500000 , B500000 },
	{ 576000 , B576000 },
	{ 921600 , B921600 },
	{ 1000000 , B1000000 },
	{ 1152000 , B1152000 },
	{ 1500000 , B1500000 },
	{ 2000000 , B2000000 },
	{ 2500000 , B2500000 },
	{ 3000000 , B3000000 },
	{ 3500000 , B3500000 },
	{ 4000000 , B4000000 },
	{ 0 , 0 } // NULL lezárás, maradjon meg utolsó elemként
};

//Soros porthoz szükséges függvény
bool set_g_speed(int speed) 
{
	int i = 0;
	for (i = 0; g_speed[i].speed != speed; i++)
	{
		if (g_speed[i].speed == 0) {
			return false;
		}
	}
	g_termio_speed = g_speed[i].bnum;
	return true;
}

//Segitséget nyújtó függvény
void print_help(void)
{
	printf("Help for PEP template APP\n");
	printf("Command line parameters:\n");
	printf("    -h                           : Print help\n");
	printf("    -s d=port_file,s=baud_rate   : Set serial port device file and baud rate\n");
}


//Adatküldés a gecko számára
int8_t dataforgecko(int serial_fd)
{
    //Beolvasás a terminálból
    read(STDIN_FILENO, &gecko_in, 1);
    
    switch(gecko_in)
    {
        //Kis és nagy betűk le kezelése
        case 'j':
        case 'J':
            gecko_out[0] = 'j';
            break;
        case 'b':
        case 'B':
            gecko_out[0] = 'b';
            break;
        case '\n':
            break;
        default:
            printf("Helytelen bemenet!\n");
            break;
    }
    
    //Adatküldés a gecko számára
    write(serial_fd, &gecko_out, 1);
    
    return 0;
}

//Adatfogadás a gecko-tól
uint8_t datafromgecko(int serial_fd)
{
    //ideiglenes változó amibe fogadjuk az adatot a gecko-tól
    char tmp[4];  
    
    read(serial_fd, &tmp, 3);
    
    strcpy(result, tmp);
    
    //Itt lépünk ki a játékból
    EXIT_game = true;
    
    return 0;
}

//A nehézségi szint beolvasásáért felelős függvény 
uint8_t readlevel(int serial_fd)
{
    //beolvasás a terminálból
    read(STDIN_FILENO, &level, 1);

    //kis és nagy betük lekezelése és hogy érvényes bemenet jött e 
    switch(level)
    {
        case 't':
        case 'T':
            strcpy(difficulty_level, "Túl könnyű");
            tmp_level[0] = '1';
           
            break;
        case 'k':
        case 'E':
            strcpy(difficulty_level, "Könnyű");
            tmp_level[0] = '2';
           
            break;
        case 'n':
        case 'N':
            strcpy(difficulty_level, "Normál");
            tmp_level[0] = '3';
            
            break;
        case 'm':
        case 'M':
            strcpy(difficulty_level, "Közepes");
            tmp_level[0] = '4';
            
            break;
        case 'h':
        case 'H':
            strcpy(difficulty_level, "Nehéz");
            tmp_level[0] = '5';
            
            break;
        case 'x':
        case 'X':
            strcpy(difficulty_level, "Extrém");
            tmp_level[0] = '6';
            
            break;
        case '\n':
            break;
        default:
            printf("Helytelen bemenet!\n");
            break;
    }


}

//A nehézségi szint és a kezdő karakter kiküldésért felelős függvény a mikrokontroller számára
uint8_t sendlevel(int serial_fd)
{
    write(serial_fd, &tmp_level[0], 1);
    write(serial_fd, &start[0], 1);
}


int main(int argc, char *argv[])
{
    int opt;
	int i;

	// Soros porthoz szükséges dolgok
	enum {
		DEVICE_OPT = 0,
		SPEED_OPT
	};

	char *const token[] = {
		[DEVICE_OPT] = "d",
		[SPEED_OPT] = "s",
		NULL
	};

	char *subopts;
	char *value;
	int errfnd = 0;

	if (argc <= 1 ) {
		printf("No command line parameters, does not know what to do...\n");
	}

	// Printing command line arguments if CMDLINE_DBG is set
	if (CMDLINE_DBG)
	{
		printf("The arguments supplied are (ARG_NUM: ARG_VALUE):\n");
		for(i = 0; i < argc; i++)
		{
			printf("%d: %s\n", i, argv[i]);
		}
	}

	// Handling commmad line arguments, and storing them in globals
	while((opt = getopt(argc, argv, "hs:o:i:")) != -1)
	{
		switch(opt)
		{
			case 'h':
				if (CMDLINE_DBG) printf("-h cmd line par received, printing help\n");
				print_help();
				exit(EXIT_SUCCESS);
				break;
			case 's':
				if (CMDLINE_DBG) printf("-s cmd line par received, setting serial port\n");
				subopts = optarg;
				while ((*subopts != '\0') && !errfnd) {
					switch (getsubopt(&subopts, token, &value)){
						case DEVICE_OPT:
							if (strlen(value) < CFGSTR_SIZE) {
								strcpy(g_serial_device,value);
								if (CMDLINE_DBG) printf("Serial port: %s\n",g_serial_device);
							}
							else {
								printf("Serial device file name is too long (max size is %d), exiting...\n",CFGSTR_SIZE);
								exit(EXIT_FAILURE);
							}
							break;
						case SPEED_OPT:
							g_serial_speed = atoi(value);
							if (g_serial_speed == 0) {

								printf("Serial device speed is invalid, exiting...\n");
								exit(EXIT_FAILURE);
							}
							if (set_g_speed(g_serial_speed)) {
								printf("Serial port speed: %d (%#x)\n",g_serial_speed,g_termio_speed);
								printf("B115200 %x\n",B115200);
							}
							else {
								printf("Specified serial speed is not supported by termios.h\n");
								exit(EXIT_FAILURE);
							}
							break;
					}
				}
				break;
			default:
			if (CMDLINE_DBG) printf("Unknown command line parameter is received\n");
				break;
		}
	}
    
    //termios struktúra létrehozása
    struct termios gecko_serial;
    int serial_fd;
    int out_fd;
    memset(&gecko_serial, 0, sizeof(gecko_serial));
    
    //struktúra kitöltése
    gecko_serial.c_iflag = 0;
    gecko_serial.c_oflag = 0;
    gecko_serial.c_cflag = CS8 | CREAD | CLOCAL;   //8-bites keretméret, vétel engedélyezése, modem control tiltása
    gecko_serial.c_lflag = 0;
    gecko_serial.c_cc[VMIN] = 1;                  //karakterenkénti olvasás engedélyezése
    gecko_serial.c_cc[VTIME] = 5;                 //nem-kanonikus olvasás időlimitje tizedmásodpercben
    
    serial_fd = open(g_serial_device, O_RDWR);
    
    if(serial_fd < 0)
    {
        write(STDERR_FILENO, "Nem tudta megnyitni a soros portot!\n", 37);
        exit(EXIT_FAILURE);
    }
    
    cfsetospeed(&gecko_serial, g_termio_speed);         //adó sebességének beállítása
    cfsetispeed(&gecko_serial, g_termio_speed);         //vevő sebességének beállítása
    
    //korábban egybegyűjtött beállítások alkalmazása
    tcsetattr(serial_fd, TCSANOW, &gecko_serial);
    

    //Játék kezdete
    printf("Játék leírás:\n");
    printf("%s",game);
    printf( "Válassz az alábbi nehézségi szintek közül:\n");
    printf( "t-túl könnyű, k-könnyű, n-normál, m-közepes, h-nehéz, x-extrém\n"); 
    
    while (!EXIT_level)
	{
         // Required for select()
        int selrval;
        fd_set rfds;
        fd_set wfds;
        struct timeval tv;
            
        FD_ZERO(&rfds);
        FD_SET(STDIN_FILENO, &rfds);	//std iinputra várunk
        FD_SET(serial_fd, &rfds);
            
        FD_ZERO(&wfds);
        FD_SET(STDOUT_FILENO, &wfds);
        FD_SET(serial_fd, &wfds);
            
        // Időtúllépés
        tv.tv_sec = 30;
        tv.tv_usec = 0;
        
		selrval = select(serial_fd+1, &rfds, NULL, NULL, &tv);
		
        if(selrval == -1)
        {
            write(STDOUT_FILENO, "Nem sikerült a select() függvényhívás!\n", 40);
        }
        else if(selrval > 0)
        {
            
            if(FD_ISSET(STDIN_FILENO, &rfds))
            {
                readlevel(serial_fd);
                sendlevel(serial_fd);
                EXIT_level=true;
            }
  
        }
    }

     


    while (!EXIT_game)
	{
        // Required for select()
        int selrval;
        fd_set rfds;
        fd_set wfds;
        struct timeval tv;
            
        FD_ZERO(&rfds);
        FD_SET(STDIN_FILENO, &rfds);	//std iinputra várunk
        FD_SET(serial_fd, &rfds);
            
        FD_ZERO(&wfds);
        FD_SET(STDOUT_FILENO, &wfds);
        FD_SET(serial_fd, &wfds);
            
        // Időtúllépés
        tv.tv_sec = 30;
        tv.tv_usec = 0;

        
		
		
		selrval = select(serial_fd+1, &rfds, NULL, NULL, &tv);
		
        if(selrval == -1)
        {
            write(STDIN_FILENO, "Nem sikerült a select() függvényhívás!\n", 40);
        }
        else if(selrval > 0)
        {
            write(serial_fd,&start[0],1);

            if(FD_ISSET(STDIN_FILENO, &rfds))
            {
                dataforgecko(serial_fd);
            }
            
            if(FD_ISSET(serial_fd, &rfds))
            {
                datafromgecko(serial_fd);
            }
        }
    }
    
    printf("Írd be a játékos nevedet:\n");
     while (!EXIT_player)
	{

         // Required for select()
        int selrval;
        fd_set rfds;
        fd_set wfds;
        struct timeval tv;
            
        FD_ZERO(&rfds);
        FD_SET(STDIN_FILENO, &rfds);	//std iinputra várunk
        FD_SET(serial_fd, &rfds);
            
        FD_ZERO(&wfds);
        FD_SET(STDOUT_FILENO, &wfds);
        FD_SET(serial_fd, &wfds);
            
        // Időtúllépés
        tv.tv_sec = 30;
        tv.tv_usec = 0;
		
		selrval = select(serial_fd+1, &rfds, NULL, NULL, &tv);
		
        if(selrval == -1)
        {
            write(STDIN_FILENO, "Nem sikerült a select() függvényhívás!\n", 40);
        }
        else if(selrval > 0)
        {
            
            
            if(FD_ISSET(STDIN_FILENO, &rfds))   //adat van a standart inputon
            {
                //maximum BUFLEN mennyiségű karakter olvasása az STDIN-ről
                ssize_t name = read(STDIN_FILENO, &player_name, BUFLEN);
                //printf("%s",player_name);
                //hibakezelés, ha nem tud beolvasni a standart input-ról
                if(name == -1)
                {
                    write(STDOUT_FILENO, "Hiba!\n", 7);
                    EXIT_player = true;
                }
            EXIT_player = true;
            }
        }
    }


    //soros port bezárása
    close(serial_fd);
    
    //a játékos név és az eredmény kiíratása eredmenyek fájlba
    FILE *fptr;
    fptr = fopen("eredmenyek", "w");
    
    //hibakezelés, ha nem sikerült megnyitni a fájlt  
    if(fptr == NULL)
    {
        write(STDOUT_FILENO, "Error during opening the file!\n", 32);
        exit(1);
    }
    player_name[strlen(player_name)-1]='\0';
    //kicsit formázva az eredmények beíratása
    fprintf(fptr, "%s", player_name);
    fprintf(fptr, "     "),
    fprintf(fptr, "%s", difficulty_level);
    fprintf(fptr, "%s", "     ");
    fprintf(fptr, "%s", "     25/");
    fprintf(fptr, "%s", result);
    fprintf(fptr, "%s", "\n");
    
    //a fájl bezárása
    fclose(fptr);
    
    //Ezt ki kell kommentezni ha szeretnénk látni a terminálban az eredményt is nem csak a fájlban
    //printf("Név: %s     Nehézségi szint: %s     25/%s \n",player_name,difficulty_level,result);
    
    return 0;
}


