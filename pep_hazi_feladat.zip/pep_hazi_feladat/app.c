/***************************************************************************//**
 * @file
 * @brief Top level application functions
 *******************************************************************************
 * # License
 * <b>Copyright 2020 Silicon Laboratories Inc. www.silabs.com</b>
 *******************************************************************************
 *
 * The licensor of this software is Silicon Laboratories Inc. Your use of this
 * software is governed by the terms of Silicon Labs Master Software License
 * Agreement (MSLA) available at
 * www.silabs.com/about-us/legal/master-software-license-agreement. This
 * software is distributed to you in Source Code format and is governed by the
 * sections of the MSLA applicable to Source Code.
 *
 ******************************************************************************/

/***************************************************************************//**
 * Initialize application.
 ******************************************************************************/
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <em_lcd.h>
#include <stdlib.h>

#include <FreeRTOS.h>
#include <task.h>
#include <queue.h>
#include <semphr.h>
#include <em_usart.h>

#include "game.h"
#include "segmentlcd.h"
#include "segmentlcd_individual.h"
#include "uart_individual.h"

TaskHandle_t hTaskMain;
TaskHandle_t hTaskInit;
TaskHandle_t hTaskControl;

QueueHandle_t  Qlevel,Q_UART;

SemaphoreHandle_t  Levelset;
SemaphoreHandle_t guard;

uint8_t bucket_place = 0;
char result[3];

void UART0_RX_IRQHandler(void)
{
  //kiolvassa a kapott adatot
  uint8_t UARTvalue = 0;
  BaseType_t xSwitchRequired;
  UARTvalue = USART_RxDataGet(UART0);
  xQueueSendFromISR(Q_UART, &UARTvalue, &xSwitchRequired);
  // t�rli az UART0 megszak�t�sflagj�t
  USART_IntClear(UART0, USART_IEN_RXDATAV);
//  xSwitchRequired = xTaskResumeFromISR(hTaskControl);
  portYIELD_FROM_ISR(xSwitchRequired);
}

static void prvTaskControl(void* pvParam)
{
  uint8_t UARTvalue;
  while(1)
    {
      xQueueReceive(Q_UART, &UARTvalue, portMAX_DELAY);
      xSemaphoreTake(guard, portMAX_DELAY);
      if(( (char)UARTvalue == 'j' ) || ( (char)UARTvalue == 'b' ))
        {
          bucket_step( (char)UARTvalue, &bucket_place);
        }
      xSemaphoreGive(guard);
    }

}

static void prvTaskMain(void* pvParam)
{
  SegmentLCD_LowerCharSegments_TypeDef lowerCharSegments[SEGMENT_LCD_NUM_OF_LOWER_CHARS];
  vTaskSuspend(NULL);
  uint8_t Level;
  xQueueReceive(Qlevel, &Level, portMAX_DELAY);
  uint8_t time_to_ripe = 4;
  uint16_t Level_time_init = 53000;
   switch(Level){                                            //delay()-be kell Level_time_init/50
       case 1: Level_time_init = 53000; time_to_ripe = 4;
         break;
       case 2: Level_time_init = 43000; time_to_ripe = 4;
         break;
       case 3: Level_time_init = 43000; time_to_ripe = 3;
         break;
       case 4: Level_time_init = 33000; time_to_ripe = 3;
         break;
       case 5: Level_time_init = 33000; time_to_ripe = 2;
         break;
       case 6: Level_time_init = 25000; time_to_ripe = 2;
           break;
   }


     SegmentLCD_Init(false);
     SegmentLCD_Symbol(LCD_SYMBOL_COL10, 1);
     score_count_display(0,0);
     lcd_update_bucket(bucket_place);

     uint8_t place_of_bananas[4] = {0};
     uint8_t order_of_trees[26];
     for(int i = 0; i < 26; i++)
     {
       order_of_trees[i] = ((rand()) % 3);
     }


     /* Infinite loop */
     uint8_t cntr = 0;  // Timer megszak�t�sait sz�molja
     uint8_t catchnum = 0; //Elkapott ban�nok sz�ma
     uint8_t fallnum = 0; //Lehult ban�nok sz�ma
     uint8_t nextTree = 0; //A f�k sorrendj�t tartalmaz� t�mben jel�li ki a soron k�vetkez�t
     while (fallnum < 25)
     {
       /*Timer megszak�t�s teljesk�r� lekezel�se */
       vTaskDelay(Level_time_init/50);
       xSemaphoreTake(guard, portMAX_DELAY);
       cntr++;
         if((time_to_ripe - 1) == (cntr % time_to_ripe))
            {
              lowerCharSegments[order_of_trees[nextTree]].a = 1;
            }
         if(0 == (cntr % time_to_ripe))
           {
             lowerCharSegments[order_of_trees[nextTree]].a = 0;
             place_of_bananas[order_of_trees[nextTree]] += 1;
             nextTree++;                                   // t�lcsordul�s ellen v�fekezni
           }
         SegmentLCD_LowerSegments(lowerCharSegments); //�r�snek a jelz�s�t irja ki
         lcd_update_bananas(place_of_bananas); //ban�nok helyzet�t friss�ti
         //ellen�rzi, hogy a j�t�kos elkapott e egy ban�nt
         if(check_catch(place_of_bananas, bucket_place, &fallnum))
           {  //ellen�rzi, hogy a j�t�kos elkapott e egy ban�nt
             catchnum++;
           }
         score_count_display(fallnum, catchnum);//Score board kijelz� friss�t�se
         lcd_update_bucket(bucket_place);

         xSemaphoreGive(guard);
       }

     int characters;
     characters = sprintf(result, "%d", catchnum);

     for(int i=0; i < characters; i++)
       {
         USART_Tx(UART0, result[i]);
       }
     vTaskDelete(NULL);
}


static void prvTaskInit(void* pvParam)
{
  UartInit();
  uint8_t UARTvalue;
  uint8_t Level = 1;
   while((char)UARTvalue != 's')
     {
       xQueueReceive(Q_UART, &UARTvalue, portMAX_DELAY);
       if(UARTvalue >= '1' && UARTvalue <= '6')
         {
           Level = (int)UARTvalue - 0x30;
         }

     }
   xQueueSend(Qlevel,&Level,portMAX_DELAY);
   vTaskResume(hTaskMain);
   vTaskDelete(NULL);
}


void app_init(void)
{
  Qlevel=xQueueCreate(1, sizeof(uint32_t));
  Q_UART=xQueueCreate(1, sizeof(uint32_t));

  guard = xSemaphoreCreateMutex();
  Levelset = xSemaphoreCreateBinary();

  xTaskCreate(prvTaskMain, "main_task", configMINIMAL_SECURE_STACK_SIZE, NULL, tskIDLE_PRIORITY + 1, &hTaskMain);
  xTaskCreate(prvTaskInit, "init_task", configMINIMAL_SECURE_STACK_SIZE, NULL, tskIDLE_PRIORITY + 3, &hTaskInit);
  xTaskCreate(prvTaskControl, "control_task", configMINIMAL_SECURE_STACK_SIZE, NULL, tskIDLE_PRIORITY + 2, &hTaskControl);
}

/***************************************************************************//**
 * App ticking function.
 ******************************************************************************/
void app_process_action(void)
{
}
