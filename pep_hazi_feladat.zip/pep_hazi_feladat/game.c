/* ----------------------------------------------------------------------------
 *  INCLUDES
 * ------------------------------------------------------------------------- */
#include "stdint.h"
#include "em_device.h"
#include "em_chip.h"
#include "segmentlcd.h"
#include "segmentlcd_individual.h"
#include "game.h"

// Szegmens vez�rl�s�hez sz�ks�ges tipusok
SegmentLCD_UpperCharSegments_TypeDef upperCharSegments[SEGMENT_LCD_NUM_OF_UPPER_CHARS];
SegmentLCD_LowerCharSegments_TypeDef lowerCharSegments[SEGMENT_LCD_NUM_OF_LOWER_CHARS];

/* ----------------------------------------------------------------------------
 *  FUNCTION DEFINITIONS
 * ------------------------------------------------------------------------- */

void lcd_update_bananas(uint8_t *place_of_bananas){
	for(int i = 0; i < 4; i++){
		if(((place_of_bananas[i] & 0b11) == 0b01) | ((place_of_bananas[i] & 0b11) == 0b11))
			lowerCharSegments[i].j = 1;
		else
			lowerCharSegments[i].j = 0;
		if(((place_of_bananas[i] & 0b11) == 0b10) | ((place_of_bananas[i] & 0b11) == 0b11))
			lowerCharSegments[i].p = 1;
		else
			lowerCharSegments[i].p = 0;
	}
	SegmentLCD_LowerSegments(lowerCharSegments);
	for(int i = 0; i < 4; i++)
		place_of_bananas[i] = place_of_bananas[i] << 1;
}

void lcd_update_bucket(uint8_t bucket_place){
	for(int i = 0; i < 4; i++)
		if(i == bucket_place)
			lowerCharSegments[i].d = 1;
		else
			lowerCharSegments[i].d = 0;
	SegmentLCD_LowerSegments(lowerCharSegments);
}

void bucket_step(char command, uint8_t *bucket_place){
	if(command == 'j'){
		if((*bucket_place) < 3)
			(*bucket_place)++;
	}
	else if(command == 'b')
		if((*bucket_place) > 0)
			(*bucket_place)--;
}

void score_count_display(uint8_t fallen, uint8_t hit){
	const uint8_t digits[] = {0x3F, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x07, 0x7F, 0x67};
	uint8_t temp = hit - (hit % 10);
	upperCharSegments[0].raw = digits[hit % 10];
	upperCharSegments[1].raw = digits[temp / 10];
	upperCharSegments[2].raw = digits[fallen % 10];
	temp = fallen - (fallen % 10);
	upperCharSegments[3].raw = digits[temp / 10];
	SegmentLCD_UpperSegments(upperCharSegments);
}

bool check_catch(uint8_t *place_of_bananas, uint8_t bucket_place, uint8_t *fallnum){
	uint8_t temp;
	for(int i = 0; i < 4; i++){
		temp = place_of_bananas[i];
		temp = temp >> 3; //az�rt kell t�bb mert ki�r�s utan az lcd_update_bananas mindig shift-el
		if(temp){
			(*fallnum)++;
			place_of_bananas[i] -= 0b1000;
			if(i == bucket_place)
				return true;
		}
	}
	return false;
}















