/* ----------------------------------------------------------------------------
 *  INCLUDES
 * ------------------------------------------------------------------------- */
#include "stdint.h"
#include "stdbool.h"

/* ----------------------------------------------------------------------------
 *  FUNCTION PROTOTYPES
 * ------------------------------------------------------------------------- */

/****************************************************//*
 * Megkapva a ban�nok hely�t t�rol� t�mb�t, azokat
 * 	megjelen�ti, �s a ban�nok hely�t friss�ti az
 * 	es�snek megfelel�en.
 ******************************************************/
void lcd_update_bananas(uint8_t *place_of_bananas);


/****************************************************//*
 * A bucket_place glob�lis v�ltoz� szerint jelen�ti meg
 * 	a kosarat az LCD kijelz�n.
 ******************************************************/
void lcd_update_bucket(uint8_t bucket_place);

/****************************************************//*
 * A kos�r hely�t �rja, figyelve, hogy a kos�r ne
 * 	tudjon a p�lya sz�l�n tovabbmenni.
 ******************************************************/
void bucket_step(char command, uint8_t *bucket_place);

/****************************************************//*
 * A lehullott, �s elkapott ban�nok sz�m�t jelzi ki az
 * LCD kijelz�n
 ******************************************************/
void score_count_display(uint8_t fallen, uint8_t hit);

/****************************************************//*
 * A j�t�k egy adott �llapot�ban megvizsg�lja, hogy
 * 	a kos�r �pp elkapja e a ban�nt.
 ******************************************************/
bool check_catch(uint8_t *place_of_bananas, uint8_t bucket_place, uint8_t *fallnum);






