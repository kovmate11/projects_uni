#include "em_device.h"
#include "em_chip.h"
#include <stdio.h>
#include "em_usart.h"
#include "em_cmu.h"
#include "retargetserial.h"
#include "em_system.h"
#include "em_gpio.h"
#include "em_core.h"

#define USER_LOCATION 0x100

enum state{
	start, sync, pid, data, stop
};

uint8_t current_state;

void MotorDriver_Init(void)
{
//	CMU_ClockEnable(cmuClock_GPIO, true);

	GPIO_PinModeSet(gpioPortD, 2, gpioModePushPull, 1);		//IN1
	GPIO_PinModeSet(gpioPortD, 3, gpioModePushPull, 1);		//IN2
	GPIO_PinModeSet(gpioPortD, 4, gpioModePushPull, 1);		//IN3
	GPIO_PinModeSet(gpioPortD, 5, gpioModePushPull, 1);		//IN4
	GPIO_PinModeSet(gpioPortC, 6, gpioModePushPull, 1);		//EN1
	GPIO_PinModeSet(gpioPortB, 12, gpioModePushPull, 1);	//EN2
	GPIO_PinModeSet(gpioPortB, 11, gpioModePushPull, 1);	//EN3
	GPIO_PinModeSet(gpioPortC, 5, gpioModePushPull, 1);		//EN4
	GPIO_PinModeSet(gpioPortD, 6, gpioModePushPull, 1);		//NFAULT
	GPIO_PinModeSet(gpioPortD, 7, gpioModePushPull, 1);		//NRESET
}

void MotorDriver_SwitchOn1(void)
{
	GPIO_PinOutSet(gpioPortD,2);
	GPIO_PinOutSet(gpioPortC,5);
}

void MotorDriver_SwitchOff1(void)
{
	GPIO_PinOutClear(gpioPortD,2);
	GPIO_PinOutSet(gpioPortC,5);
}

void MotorDriver_SwitchOn2(void)
{
	GPIO_PinOutSet(gpioPortD,3);
	GPIO_PinOutSet(gpioPortB,11);
}

void MotorDriver_SwitchOff2(void)
{
	GPIO_PinOutClear(gpioPortD,3);
	GPIO_PinOutSet(gpioPortB,11);
}

void MotorDriver_SwitchOn3(void)
{
	GPIO_PinOutSet(gpioPortD,4);
	GPIO_PinOutSet(gpioPortB,12);
}

void MotorDriver_SwitchOff3(void)
{
	GPIO_PinOutClear(gpioPortD,4);
	GPIO_PinOutSet(gpioPortB,12);
}

void MotorDriver_SwitchOn4(void)
{
	GPIO_PinOutSet(gpioPortD,5);
	GPIO_PinOutSet(gpioPortC,6);
}

void MotorDriver_SwitchOff4(void)
{
	GPIO_PinOutClear(gpioPortD,5);
	GPIO_PinOutSet(gpioPortC,6);
}

void MotorDriver_Disable1(void)
{
	GPIO_PinOutClear(gpioPortC,5);
}

void MotorDriver_Disable2(void)
{
	GPIO_PinOutClear(gpioPortB,11);
}

void MotorDriver_Disable3(void)
{
	GPIO_PinOutClear(gpioPortB,12);
}

void MotorDriver_Disable4(void)
{
	GPIO_PinOutClear(gpioPortC,6);
}

void Drive(uint8_t data0, uint8_t data1)
{
	//up
	if(data0==2 && data1 == 0)
	{
		MotorDriver_SwitchOn1();
		MotorDriver_SwitchOff4();
		MotorDriver_Disable3();
	}
	//down
	else if(data0==1 && data1 == 0)
	{
		MotorDriver_SwitchOn4();
		MotorDriver_SwitchOff1();
		MotorDriver_Disable3();
	}
	//left
	else if(data0==0 && data1 == 1)
	{
		MotorDriver_SwitchOn4();
		MotorDriver_SwitchOff3();
		MotorDriver_Disable1();
	}
	//right
	else if(data0==0 && data1 == 2)
	{
		MotorDriver_SwitchOn3();
		MotorDriver_SwitchOff4();
		MotorDriver_Disable1();
	}
	//default
	if(data0 == 0 && data1 == 0)
	{
		MotorDriver_Disable1();
		MotorDriver_Disable4();
		MotorDriver_Disable3();
	}
}

int main(void)
{

	USART_InitAsync_TypeDef UART1_init = USART_INITASYNC_DEFAULT;
	/* Chip errata */
	CHIP_Init();

	/*orajel*/
	CMU_ClockEnable(cmuClock_GPIO, true);
	CMU_ClockEnable(cmuClock_USART1, true);

	/*GPIO*/
	GPIO_PinModeSet(gpioPortD, 1, gpioModeInput, 1); //RX
	GPIO_PinModeSet(gpioPortD, 0, gpioModePushPull, 1); //TX

	/*UART0: 115200 baud, 8N1*/
	UART1_init.baudrate = 19200;
	UART1_init.databits = usartDatabits8;
	UART1_init.parity = usartNoParity;
	UART1_init.stopbits = usartStopbits1;
	USART_InitAsync(USART1, &UART1_init);


	/* Enable I/O and set location */
	USART1->ROUTE = USART_ROUTE_RXPEN | USART_ROUTE_TXPEN | USER_LOCATION;

	/*UART hasznalata*/
	//USART_Tx(UART0, 'D');
	USART_Enable(USART1,usartEnable);

	/*változók inicializálása*/
	uint8_t uart_data;
	uint8_t data0;
	uint8_t data1;
	uint8_t checksum;

	RETARGET_SerialInit();
	RETARGET_SerialCrLf(true);

	//printf("\r\nHello Word! :) \r\n");

	MotorDriver_Init();
	while (1)
	{
		uart_data = USART_Rx(USART1);

		printf("%x \n", uart_data);

		switch(current_state){
		case start:
			if(uart_data == 0x00)
				current_state = sync;
			else
				current_state = start;
			break;
		case sync:
			if(uart_data == 0x55)
				current_state = pid;
			else
				current_state = start;
			break;
		case pid:
			if(uart_data == 0x8b)
				current_state = data;
			else
				current_state = start;
			break;
		case data:
			data0 = uart_data;
			data1 = USART_Rx(USART1);
			checksum = USART_Rx(USART1);
			Drive(data0, data1);
			printf("Data:\n");
			printf("%x %x \n", data0, data1);
		}
	}
}
